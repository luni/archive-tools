This is a readme file for v2 torrent testing.
